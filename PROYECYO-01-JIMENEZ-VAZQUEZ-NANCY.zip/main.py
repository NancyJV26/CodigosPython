from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches
"""
Informacion de LifeStore_SalesList data:

lifestore_searches = [id_search, id product]
lifestore_sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore_products = [id_product, name, price, category, stock]
"""
#creacion del login y numero de intentos
Usuario_ingreso = False
numero_intentos = 0
mensaje_ingreso = 'Bienvenido al sistema!\nFavor de ingresar usuario y contraseña para acceder.'
print(mensaje_ingreso)
while not Usuario_ingreso:
  #ingreso del usuario, primera vez
  Usuario = input('Usuario: ')
  Contraseña = input('Contraseña: ')
  numero_intentos += 1
  #mensajes de error cuando el usuario se equivoque
  if Usuario == 'nancy' and Contraseña == 'nancy26':
    Usuario_ingreso = True
    print('Hola de nuevo!')
  else:
    if Usuario == 'nancy':
      print('Contraseña Incorrecta!')
    else:
      print(f'Usuario: "{Usuario}" no se encuentra registrado')
    print(f'Te quedan {3 - numero_intentos} intentos mas!')
  if numero_intentos == 3:
    
    exit()
print('Usuario y Contraseña correctos!')
#Creacion de un menu de opciones
menu = """
Escoga un opcion para acceder a su información:
[1] Productos con Mayores Ventas
[2] Productos con Mayores Búsquedas
[3] Productos con Menores Ventas
[4] Productos con Menores Búsquedas
[5] Productos con Mejores Reseñas
[6] Productos con Peores Reseñas
[7] Total de Ingresos y Ventas Promedio Mensuales
[8] Total Anual y Meses con más Ventas al Año
"""
print(menu)
opcion = input('Digite una opción: ')
#Parte 1
nombre_producto = []
ventas = []
nombre_producto = [venta [1] for venta in lifestore_sales]
#Mayores Ventas
if opcion == '1':
  #Creacion de la lista con los mayores ventas
  for venta in lifestore_products:
    lista1 = [] 
    ventas.append(lista1)
    for k in range(1):
      #Guardando los ID de los productos
      lista1.append(venta[0])
      #Guardando los nombre de los productos
      lista1.append(venta[1])
      #Generando la cuenta de las ventas
      lista1.append(nombre_producto.count(venta[0])) 
      lista1.append(venta[-2])
  def sort(ventas):
    ventas.sort(key=lambda x: x[2])
    return ventas
  ventas = sort(ventas)
  print('\n Mayores Ventas de Productos')
  for i in range(0,5):
    print(f'ID:{ventas[i][0]}\t Nombre: {ventas[i][1]}\t Venta:{ventas[i][2]}')
#Mayores Búsquedas
busqueda_producto = []
cantidad_busqueda = []
busqueda_producto = [busqueda[1] for busqueda in lifestore_searches]
if opcion == '2':
  for busqueda in lifestore_products:
    lista2 = []
    cantidad_busqueda.append(lista2)
    for k in range(1):
      #Guardando los ID de los productos
      lista2.append(busqueda[0])
      #Guardando los nombre de los productos
      lista2.append(busqueda[1])
      #Generando la cuenta de las busquedas
      lista2.append(busqueda_producto.count(busqueda[0])) 
      lista2.append(busqueda[-2])
  def sort(cantidad_busqueda):
    cantidad_busqueda.sort(key=lambda x: x[2])
    return cantidad_busqueda
  cantidad_busqueda =sort(cantidad_busqueda)
  print('\n Mayores Busquedas de Productos')
  for i in range(0,10):
    print(f'ID:{cantidad_busqueda[i][0]}\t Nombre: {cantidad_busqueda[i][1]}\t Búsquedas:{cantidad_busqueda[i][2]}')
#Menores Ventas por categorias
categorias = {}
procesadores = {}
tarjetas_video = {}
tarjetas_madre = {}
disco_duro = {}
usb = {}
pantallas = {}
bocinas = {}
audifonos = {}
categorias = [item[-2] for item in lifestore_products]
categorias = list(dict.fromkeys(categorias))
for item in ventas:
  if categorias[0] in item:
    procesadores.append(item[0:4])
  elif categorias[1] in item:
    tarjetas_video.append(item[0:4])
  elif categorias[2] in item:
    tarjetas_madre.append(item[0:4])
  elif categorias[3] in item:
    disco_duro.append(item[0:4])
  elif categorias[4] in item:
    usb.append(item[0:4])
  elif categorias[5] in item:
    pantallas.append(item[0:4])
  elif categorias[6] in item:
    bocinas.append(item[0:4])
  elif categorias[7] in item:
    audifonos.append(item[0:4])
if opcion  == '3':
  print('Menores Ventas por Categorías')
  print('\n Menores Ventas en Procesadores')
  for i in range(0,5):
    print(f"ID : {procesadores[i][0]} \t Nombre: {procesadores[i][1]} \t Menores Ventas: {procesadores[i][3]}")
  print('\n Menores Ventas en Tarjetas de Video')
  for i in range(5):
    print(f'ID:{tarjetas_video[i][0]}\t Nombre: {tarjetas_video[i][1]}\t Menores Ventas: {tarjetas_video[i][3]}')
  print('\n Menores Ventas en Tarjetas Madre')
  for i in range(5):
    print(f'ID:{tarjetas_madre[i][0]}\t Nombre: {tarjetas_madre[i][1]}\t Menores Ventas: {tarjetas_madre[i][3]}')
  print('\n Menores Ventas en Discos Duros')
  for i in range(5):
    print(f'ID:{disco_duro[i][0]}\t Nombre: {disco_duro[i][1]}\t Menores Ventas: {disco_duro[i][-2]}')
  print('\n Menores Ventas en USB')
  for i in range(2):
    print(f'ID:{usb[i][0]}\t Nombre: {usb[i][1]}\t Menores Ventas: {usb[i][5]}')
  print('\n Menores Ventas en Pantallas')
  for i in range(5):
    print(f'ID:{pantallas[i][0]}\t Nombre: {pantallas[i][1]}\t Menores Ventas: {pantallas[i][5]}')
  print('\n Menores Ventas en Bocinas')
  for i in range(5):
    print(f'ID:{bocinas[i][0]}\t Nombre: {bocinas[i][1]}\t Menores Ventas: {bocinas[i][5]}')
  print('\n Menores Ventas en Audifonos')
  for i in range(5):
    print(f'ID:{audifonos[i][0]}\t Nombre: {audifonos[i][1]}\t Menores Ventas: {audifonos[i][2]}')
#Menores Ventas por categorias
procesadores2 = []
tarjetas_video2 = []
tarjetas_madre2 = []
disco_duro2 = []
usb2 = []
pantallas2 = []
bocinas2 = []
audifonos2 = []
if opcion == '4': 
  for item in ventas:
    if categorias[0] in item:
      procesadores2.append(item[:3])
    elif categorias[1] in item:
      tarjetas_video2.append(item[:3])
    elif categorias[2] in item:
      tarjetas_madre2.append(item[:3])
    elif categorias[3] in item:
      disco_duro2.append(item[:3])
    elif categorias[4] in item:
      usb2.append(item[:3])
    elif categorias[5] in item:
      pantallas2.append(item[:3])
    elif categorias[6] in item:
      bocinas2.append(item[:3])
    elif categorias[7] in item:
      audifonos2.append(item[:3])
  print('\Menores Busquedas por Categorías')
  print('\n Menores Busquedas en Procesadores')
  for i in range(9):
    print(f'ID:{procesadores2[i][0]}\t Nombre: {procesadores2[i][1]} \t Menores Busquedas: {procesadores2[i][-1]}')
  print('\n Menores Busquedas en Tarjetas de Video')
  for i in range(10):
    print(f'ID:{tarjetas_video2[i][0]}\t Nombre: {tarjetas_video2[i][1]}\t Menores Busquedas: {tarjetas_video2[i][-1]}')
  print('\n Menores Busquedas en Tarjetas Madre')
  for i in range(10):
    print(f'ID:{tarjetas_madre2[i][0]}\t Nombre: {tarjetas_madre2[i][1]}\t Menores Busquedas: {tarjetas_madre2[i][-1]}')
  print('\n Menores Busquedas en Discos Duros')
  for i in range(10):
    print(f'ID:{disco_duro2[i][0]}\t Nombre: {disco_duro2[i][1]}\t Menores Busquedas: {disco_duro2[i][-1]}')
  print('\n Menores Busquedas en USB')
  for i in range(2):
    print(f'ID:{usb2[i][0]}\t Nombre: {usb2[i][1]}\t Menores Busquedas: {usb2[i][-1]}')
  print('\n Menores Busquedas en Pantallas')
  for i in range(10):
    print(f'ID:{pantallas2[i][0]}\t Nombre: {pantallas2[i][1]}\t Menores Busquedas: {pantallas2[i][-1]}')
  print('\n Menores Busquedas en Bocinas')
  for i in range(10):
    print(f'ID:{bocinas2[i][0]}\t Nombre: {bocinas2[i][1]}\t Menores Busquedas: {bocinas2[i][-1]}')
  print('\n Menores Busquedas en Audifonos')
  for i in range(10):
    print(f'ID:{audifonos2[i][0]}\t Nombre: {audifonos2[i][1]}\t Menores Busquedas: {audifonos2[i][-1]}')
#Parte 2
#Mejores Reseñas
if opcion == '5':
  pass 
if opcion == '6':
  pass
sale=[]
id_fecha = [[sale[0], sale[3]] for sale in lifestore_sales if sale[4] == 0]
meses = {} 
for par in id_fecha:
  id=par[0]
  _,mes,_=par[1].split('/')
  if mes not in meses.keys():
    meses[mes]=[]
  meses[mes].append(id)
if opcion == '7':
  for key in meses.keys(): 
    fecha = meses[key] 
    suma_venta = 0
    for id_venta in fecha:
      indice = id_venta -1 
      inf_venta = lifestore_sales[indice]
      id_product = inf_venta[1]
      price = lifestore_products[id_product-1][2]
      suma_venta += price
    print(key, suma_venta, f'Total ingreso y Ventas Promedio Mensual: {len(fecha)}')

if opcion == '8':
  for key in meses.keys(): 
    fecha = meses[key] 
    suma_venta = 0
    for id_venta in fecha:
      indice = id_venta -1 
      inf_venta = lifestore_sales[indice]
      id_product = inf_venta[1]
      price = lifestore_products[id_product-1][2]
      suma_venta += price
  def sort(suma_venta):
    suma_venta.sort(key=lambda x: x[0])
    return suma_venta
    suma_venta = sort(suma_venta)
  print(key, suma_venta, f'Mes con mas Venta al Año: {len(fecha)}')

else:
  print('Favor de seleccionar una opción: ')

